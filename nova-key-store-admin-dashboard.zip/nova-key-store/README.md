# NOVA KEY STORE — Admin Dashboard project

Includes a Next.js app, Supabase email-link login, private payment-receipt storage policies, and a real Supabase-backed `/admin` dashboard.

## Admin features
- Checks the signed-in account's `profiles.is_admin` flag before showing orders.
- Loads order, customer email and package details from Supabase.
- Opens private receipts using 5-minute signed links.
- Approves or rejects receipt-submitted orders; rejection can include a note.
- Marks approved orders as `key_sent`.
- Keeps Nova Key values out of the website.

## Setup
1. Create `.env.local` from `.env.example` and add your Supabase Project URL and anon/publishable key. Never use the `service_role` key in browser code.
2. Run `supabase/migrations/0001_initial.sql` and `0002_receipt_storage.sql` in the Supabase SQL Editor (if already run, do not run duplicate policies; use your existing schema).
3. Register/sign in once with the owner email address.
4. In Supabase SQL Editor run, replacing the email:
   `update public.profiles set is_admin = true where lower(email) = lower('YOUR-OWNER-EMAIL');`
5. Configure Supabase Auth Site URL and redirect URLs for the deployed domain, including `/auth/callback`.
6. Deploy the project to a Next.js-compatible host.

## Important
- Admin orders are real database rows; this dashboard does not create fake sample orders.
- Receipt bucket must remain private.
- Manually verify the KBZ Pay transfer before approving.
- Send the Nova Key manually to the customer's registered email, then click `Mark key sent`.
- Never store Nova Key numbers in the website.
- The project is source code, not a live website. It still needs environment variables and deployment.
