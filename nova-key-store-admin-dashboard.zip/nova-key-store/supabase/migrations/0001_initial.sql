create extension if not exists pgcrypto;
create table if not exists public.profiles (id uuid primary key references auth.users(id) on delete cascade,email text,is_admin boolean not null default false,created_at timestamptz not null default now());
create table if not exists public.packages (id text primary key,title text not null,bonus text not null,total_coins integer not null check(total_coins>0),price_mmk integer not null check(price_mmk>0),active boolean not null default true);
insert into public.packages(id,title,bonus,total_coins,price_mmk) values
('coin-50','50 Coin','+10 Bonus',60,10000),('coin-220','220 Coin','+20 Bonus',240,23000),('coin-325','325 Coin','+25 Bonus',350,35000),('coin-450','450 Coin','+50 Bonus',500,47000),('coin-950','950 Coin','+150 Bonus',1100,75000)
on conflict(id) do update set title=excluded.title,bonus=excluded.bonus,total_coins=excluded.total_coins,price_mmk=excluded.price_mmk;
create table if not exists public.orders(id uuid primary key default gen_random_uuid(),customer_id uuid not null references public.profiles(id),package_id text not null references public.packages(id),status text not null default 'pending_payment' check(status in('pending_payment','receipt_submitted','approved','rejected','key_sent')),receipt_path text,admin_note text,created_at timestamptz not null default now(),updated_at timestamptz not null default now(),key_sent_at timestamptz);
create index if not exists orders_customer_created_idx on public.orders(customer_id,created_at desc);
create index if not exists orders_status_created_idx on public.orders(status,created_at desc);
create or replace function public.handle_new_user() returns trigger language plpgsql security definer set search_path=public as $$ begin insert into public.profiles(id,email) values(new.id,new.email) on conflict(id) do update set email=excluded.email; return new; end; $$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users for each row execute procedure public.handle_new_user();
alter table public.profiles enable row level security; alter table public.packages enable row level security; alter table public.orders enable row level security;
create policy "profile_select_self_or_admin" on public.profiles for select using(auth.uid()=id or exists(select 1 from public.profiles p where p.id=auth.uid() and p.is_admin));
create policy "profile_update_self" on public.profiles for update using(auth.uid()=id) with check(auth.uid()=id and is_admin=(select p.is_admin from public.profiles p where p.id=auth.uid()));
create policy "packages_read_active" on public.packages for select using(active=true);
create policy "orders_read_own_or_admin" on public.orders for select using(customer_id=auth.uid() or exists(select 1 from public.profiles p where p.id=auth.uid() and p.is_admin));
create policy "customer_create_own_order" on public.orders for insert with check(customer_id=auth.uid() and status='pending_payment');
create policy "customer_submit_receipt_own_order" on public.orders for update using(customer_id=auth.uid()) with check(customer_id=auth.uid() and status in('pending_payment','receipt_submitted'));
create policy "admin_update_orders" on public.orders for update using(exists(select 1 from public.profiles p where p.id=auth.uid() and p.is_admin)) with check(exists(select 1 from public.profiles p where p.id=auth.uid() and p.is_admin));