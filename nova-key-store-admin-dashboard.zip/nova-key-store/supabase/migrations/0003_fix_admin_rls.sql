-- Fix admin checks without recursive RLS lookups.
create or replace function public.is_admin()
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1 from public.profiles
    where id = auth.uid() and is_admin = true
  );
$$;

grant execute on function public.is_admin() to authenticated;

drop policy if exists "profile_select_self_or_admin" on public.profiles;
create policy "profile_select_self_or_admin" on public.profiles
for select to authenticated
using (auth.uid() = id or public.is_admin());

drop policy if exists "profile_update_self" on public.profiles;
create policy "profile_update_self" on public.profiles
for update to authenticated
using (auth.uid() = id)
with check (
  auth.uid() = id
  and is_admin = (select p.is_admin from public.profiles p where p.id = auth.uid())
);

drop policy if exists "orders_read_own_or_admin" on public.orders;
create policy "orders_read_own_or_admin" on public.orders
for select to authenticated
using (customer_id = auth.uid() or public.is_admin());

drop policy if exists "admin_update_orders" on public.orders;
create policy "admin_update_orders" on public.orders
for update to authenticated
using (public.is_admin())
with check (public.is_admin());

drop policy if exists "customers_read_own_receipts_or_admin" on storage.objects;
create policy "customers_read_own_receipts_or_admin" on storage.objects
for select to authenticated
using (
  bucket_id = 'payment-receipts'
  and (
    (storage.foldername(name))[1] = auth.uid()::text
    or public.is_admin()
  )
);
