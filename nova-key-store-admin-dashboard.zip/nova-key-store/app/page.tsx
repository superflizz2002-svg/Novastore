"use client";
const packages = [
  ["50 Coin","+10 Bonus","10,000 MMK","60 Coins"],
  ["220 Coin","+20 Bonus","23,000 MMK","240 Coins"],
  ["325 Coin","+25 Bonus","35,000 MMK","350 Coins"],
  ["450 Coin","+50 Bonus","47,000 MMK","500 Coins"],
  ["950 Coin","+150 Bonus","75,000 MMK","1,100 Coins"]
];
export default function Home() {
  return <main className="shell">
    <header className="top"><div className="mark">RET</div><div><b>NOVA KEY STORE</b><small>RET × NOVA KEY STORE</small></div><a className="admin-link" href="/admin">Admin</a></header>
    <section className="hero"><p className="eyebrow">RET × NOVA KEY STORE</p><h1>UNLOCK YOUR<br/><span>ENTERTAINMENT</span></h1><p>Premium Nova Coin packages with a simple ordering process and personal order support.</p><a className="primary" href="#packages">View Coin Packages</a></section>
    <section id="packages"><h2>Nova Coin Packages</h2><div className="grid">{packages.map(([name,bonus,price,total])=><article className="package" key={name}><div className="coin">N</div><h3>{name}</h3><p className="bonus">{bonus}</p><p className="total">{total}</p><strong>{price}</strong><a className="order" href="/login">Login to Order</a></article>)}</div></section>
    <section className="payment"><h2>KBZ Pay</h2><p>09974709350 · U Aung Thet Oo</p><p>Payment receipts are checked manually before an order is approved.</p></section>
    <footer>Support: <a href="https://t.me/qualityvdatPP">Telegram</a> · <a href="https://www.tiktok.com/@qualityvdatp?_r=1&_t=ZS-9BFPK9DTKpZ">TikTok</a></footer>
  </main>;
}