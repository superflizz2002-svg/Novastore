import type { Metadata } from "next";
import "./globals.css";
export const metadata: Metadata = { title: "NOVA KEY STORE", description: "NOVA Coin packages and secure order support." };
export default function RootLayout({children}:{children:React.ReactNode}) {
  return <html lang="en"><body>{children}</body></html>;
}