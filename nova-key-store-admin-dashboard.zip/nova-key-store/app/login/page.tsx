"use client";
import { FormEvent, useState } from "react";
import { useSearchParams } from "next/navigation";
import { createClient } from "@/lib/supabase/client";
export default function LoginPage() {
  const [email,setEmail]=useState(""); const [message,setMessage]=useState(""); const [busy,setBusy]=useState(false);
  const params=useSearchParams(); const next=params.get("next") || "/";
  async function submit(e:FormEvent) {
    e.preventDefault(); setBusy(true); setMessage("");
    try {
      const supabase=createClient();
      const {error}=await supabase.auth.signInWithOtp({email,options:{emailRedirectTo:`${window.location.origin}/auth/callback?next=${encodeURIComponent(next)}`}});
      if(error) throw error; setMessage("Sign-in link sent. Check your email.");
    } catch(err) {setMessage(err instanceof Error?err.message:"Unable to send sign-in link.");}
    finally {setBusy(false);}
  }
  return <main className="auth"><a href="/">← Home</a><h1>Sign in</h1><p>Enter your owner email. A secure login link will be sent to you.</p><form onSubmit={submit}><input type="email" required value={email} onChange={e=>setEmail(e.target.value)} placeholder="Email address"/><button disabled={busy}>{busy?"Sending…":"Send login link"}</button></form><p>{message}</p></main>;
}