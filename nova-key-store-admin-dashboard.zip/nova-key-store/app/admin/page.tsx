 "use client";
import { useEffect, useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import { createClient } from "@/lib/supabase/client";

type Status="pending_payment"|"receipt_submitted"|"approved"|"rejected"|"key_sent";
type Order={id:string;customer_id:string;package_id:string;status:Status;receipt_path:string|null;admin_note:string|null;created_at:string;profiles?:{email:string|null}|null;packages?:{title:string;bonus:string;total_coins:number;price_mmk:number}|null};
const labels:Record<Status,string>={pending_payment:"Awaiting payment",receipt_submitted:"Receipt submitted",approved:"Approved",rejected:"Rejected",key_sent:"Key sent"};
const money=(n?:number)=>`${(n??0).toLocaleString("en-US")} MMK`;
export default function AdminPage(){
 const router=useRouter(),supabase=useMemo(()=>createClient(),[]);
 const [loading,setLoading]=useState(true),[busy,setBusy]=useState<string|null>(null),[email,setEmail]=useState("");
 const [orders,setOrders]=useState<Order[]>([]),[filter,setFilter]=useState("all"),[search,setSearch]=useState(""),[message,setMessage]=useState(""),[receipt,setReceipt]=useState<string|null>(null),[isAdmin,setIsAdmin]=useState(false);
 async function load(){
  setLoading(true);setMessage("");
  const {data:{user}}=await supabase.auth.getUser();
  if(!user){router.replace("/login?next=/admin");return;}
  setEmail(user.email??"");
  const {data:profile,error:pe}=await supabase.from("profiles").select("is_admin").eq("id",user.id).single();
  if(pe||!profile?.is_admin){setIsAdmin(false);setLoading(false);setMessage("ဤ Account ကို Admin အဖြစ် ခွင့်ပြုထားခြင်း မရှိသေးပါ။");return;}
  setIsAdmin(true);
  const {data,error}=await supabase.from("orders").select("id,customer_id,package_id,status,receipt_path,admin_note,created_at,profiles(email),packages(title,bonus,total_coins,price_mmk)").order("created_at",{ascending:false});
  if(error)setMessage(`Order များဖတ်မရပါ: ${error.message}`);else setOrders((data??[]) as unknown as Order[]);
  setLoading(false);
 }
 useEffect(()=>{void load();},[]);
 async function updateStatus(o:Order,status:Status){
  let note=o.admin_note;
  if(status==="rejected"){const answer=window.prompt("Reject လုပ်ရတဲ့အကြောင်းရင်း (မဖြည့်လည်းရ):",note??"");if(answer===null)return;note=answer;}
  setBusy(o.id);setMessage("");
  const patch:Record<string,unknown>={status,admin_note:note,updated_at:new Date().toISOString()};
  if(status==="key_sent")patch.key_sent_at=new Date().toISOString();
  const {error}=await supabase.from("orders").update(patch).eq("id",o.id);
  if(error)setMessage(`မအောင်မြင်ပါ: ${error.message}`);else{setMessage(`Order ကို ${labels[status]} အဖြစ် ပြောင်းပြီးပါပြီ။`);await load();}
  setBusy(null);
 }
 async function showReceipt(path:string|null){
  if(!path){setMessage("Receipt မတင်ရသေးပါ။");return;}
  const {data,error}=await supabase.storage.from("payment-receipts").createSignedUrl(path,300);
  if(error||!data?.signedUrl){setMessage(`Receipt ဖွင့်မရပါ: ${error?.message??"Unknown error"}`);return;}
  setReceipt(data.signedUrl);
 }
 async function signOut(){await supabase.auth.signOut();router.replace("/");}
 const shown=orders.filter(o=>(filter==="all"||o.status===filter)&&`${o.profiles?.email??""} ${o.id} ${o.packages?.title??""}`.toLowerCase().includes(search.toLowerCase()));
 const count=(s:Status)=>orders.filter(o=>o.status===s).length;
 const revenue=orders.filter(o=>o.status==="approved"||o.status==="key_sent").reduce((n,o)=>n+(o.packages?.price_mmk??0),0);
 return <main className="admin-shell">
  <header className="admin-top"><a className="admin-brand" href="/"><span className="admin-mark">RET</span><span><b>NOVA KEY STORE</b><small>ADMIN CONTROL PANEL</small></span></a><div className="admin-user"><span>{email}</span><button onClick={signOut}>Sign out</button></div></header>
  <section className="admin-content"><div className="admin-heading"><div><p className="admin-kicker">STORE MANAGEMENT</p><h1>Admin Dashboard</h1><p>Orders · Payment receipts · Fulfillment</p></div><button className="admin-refresh" onClick={()=>void load()} disabled={loading}>↻ Refresh</button></div>
   {message&&<div className="admin-message">{message}</div>}
   {loading?<div className="admin-panel">Loading…</div>:!isAdmin?<div className="admin-panel"><h2>Admin access required</h2><p>Supabase မှာ ဒီ Email ကို Admin ခွင့်ပြုချက်ပေးပြီးမှ ဝင်သုံးနိုင်ပါမယ်။</p></div>:<>
    <div className="admin-stats">
     <article><span>ALL ORDERS</span><strong>{orders.length}</strong></article>
     <article><span>RECEIPTS TO REVIEW</span><strong>{count("receipt_submitted")}</strong></article>
     <article><span>APPROVED</span><strong>{count("approved")}</strong></article>
     <article><span>KEY SENT</span><strong>{count("key_sent")}</strong></article>
     <article><span>REJECTED</span><strong>{count("rejected")}</strong></article>
     <article><span>VERIFIED SALES</span><strong>{money(revenue)}</strong></article>
    </div>
    <section className="admin-panel"><div className="admin-list-head"><div><h2>Customer Orders</h2><p>ငွေလွှဲ Receipt ကိုစစ်ပြီးမှ Approve လုပ်ပါ။</p></div><input placeholder="Search email / order / package" value={search} onChange={e=>setSearch(e.target.value)}/></div>
     <div className="admin-filters">{[["all","All"],["receipt_submitted","Receipt submitted"],["approved","Approved"],["key_sent","Key sent"],["rejected","Rejected"],["pending_payment","Awaiting payment"]].map(([v,l])=><button key={v} className={filter===v?"active":""} onClick={()=>setFilter(v)}>{l}</button>)}</div>
     <div className="admin-table-wrap"><table className="admin-table"><thead><tr><th>ORDER / CUSTOMER</th><th>PACKAGE</th><th>AMOUNT</th><th>STATUS</th><th>RECEIPT</th><th>ACTION</th></tr></thead><tbody>
      {shown.map(o=><tr key={o.id}><td><b>#{o.id.slice(0,8).toUpperCase()}</b><small>{o.profiles?.email??"Email unavailable"}</small><small>{new Date(o.created_at).toLocaleString()}</small></td><td>{o.packages?.title??o.package_id}<small>{o.packages?.bonus??""} · {o.packages?.total_coins??"—"} total</small></td><td>{money(o.packages?.price_mmk)}</td><td><span className={`status status-${o.status}`}>{labels[o.status]}</span></td><td><button className="text-action" onClick={()=>void showReceipt(o.receipt_path)}>View receipt</button></td><td><div className="admin-actions">
       {o.status==="receipt_submitted"&&<><button className="approve" disabled={busy===o.id} onClick={()=>void updateStatus(o,"approved")}>Approve</button><button className="reject" disabled={busy===o.id} onClick={()=>void updateStatus(o,"rejected")}>Reject</button></>}
       {o.status==="approved"&&<button className="approve" disabled={busy===o.id} onClick={()=>void updateStatus(o,"key_sent")}>Mark key sent</button>}
       {o.status==="rejected"&&<button onClick={()=>void updateStatus(o,"receipt_submitted")}>Re-open</button>}
       {o.status==="pending_payment"&&<span className="muted">Waiting for receipt</span>}{o.status==="key_sent"&&<span className="muted">Completed</span>}
      </div></td></tr>)}
      {!shown.length&&<tr><td colSpan={6} className="empty">No matching orders.</td></tr>}
     </tbody></table></div><p className="admin-footnote">KBZ Pay ငွေရောက်မှုကို ကိုယ်တိုင်စစ်ဆေးပြီးမှ Approve လုပ်ပါ။ Nova Key နံပါတ်များကို Website ထဲမသိမ်းပါ။ Customer Email သို့ ကိုယ်တိုင်ပို့ပြီးမှ Mark key sent လုပ်ပါ။</p>
    </section>
   </>}
  </section>
  {receipt&&<div className="receipt-backdrop" onClick={()=>setReceipt(null)}><div className="receipt-modal" onClick={e=>e.stopPropagation()}><div><b>Payment Receipt</b><button onClick={()=>setReceipt(null)}>Close ✕</button></div><iframe src={receipt} title="Payment receipt"/></div></div>}
 </main>;
}